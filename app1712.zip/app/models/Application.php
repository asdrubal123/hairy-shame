<?php

class Application extends Eloquent {
    public function country() {
        return $this->belongsTo('Country');
    }
}