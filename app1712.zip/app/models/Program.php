<?php

class Program extends Eloquent {

	protected $fillable = array('name', 'description', 'country_id', 'priority_id', 'team_id', 'level1_comment', 'level2_team_id', 'level2_comment', 'level3_team_id', 'level3_comment', 'active' );

	public static $rules = array(
		'name' => 'required|min:2',
		'description'=>'required|min:20',
		'country_id'=>'required|integer',
		'priority_id'=>'required|integer',
		'team_id'=>'required|integer',
		'level1_comment'=>'',
		'level2_team_id'=>'required|integer',
		'level2_comment'=>'',
		'level3_team_id'=>'required|integer',
		'level3_comment'=>'',
		'active'=>'integer',
	);

	public function country() {
		return $this->belongsTo('Country');
	}

	public function priority() {
		return $this->belongsTo('Priority');
	}

	public function team() {
		return $this->belongsTo('Team');
	}
	public function level2_team() {
		return $this->belongsTo('Team');
	}
	public function level3_team() {
		return $this->belongsTo('Team');
	}
}