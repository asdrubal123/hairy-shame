<?php


	class Team extends Eloquent {




    protected $softDelete = true;

	protected $fillable = array(
				'team',	
				'TeamStatus', 
				'TeamDescription', 
				'TeamSL', 
				'TeamCust', 
				'TeamTimeTable', 
				'TeamPhone', 
				'TeamConstraintPhone', 
				'TeamEmail', 
				'TeamFree1',  
				'EFree', 
				'EL1TL', 
				'EL1Phone', 
				'EL1Cell', 
				'EL1Email1', 
				'EL1Email2', 
				'EL1Comments', 
				'EL2TL', 
				'EL2Phone', 
				'EL2Cell', 
				'EL2Email1', 
				'EL2Email2', 
				'EL2Comments', 
				'EL3TL', 
				'EL3Phone', 
				'EL3Cell', 
				'EL3Email1', 
				'EL3Email2', 
				'EL3Comments', 
				'Comments'
	);

	public static $rules = array(
				'team'	=> 'required',
				'TeamStatus'	=> 'required', 
				'TeamDescription'	=> 'required',
				'TeamSL'	=> '', 
				'TeamCust'	=> '', 
				'TeamTimeTable'	=> '', 
				'TeamPhone'	=> '', 
				'TeamConstraintPhone'	=> '', 
				'TeamEmail'	=> '', 
				'TeamFree1'	=> '',  
				'EFree'	=> '', 
				'EL1TL'	=> '', 
				'EL1Phone'	=> '', 
				'EL1Cell'	=> '', 
				'EL1Email1'	=> '', 
				'EL1Email2'	=> '', 
				'EL1Comments'	=> '', 
				'EL2TL'	=> '', 
				'EL2Phone'	=> '', 
				'EL2Cell'	=> '', 
				'EL2Email1'	=> '', 
				'EL2Email2'	=> '', 
				'EL2Comments'	=> '', 
				'EL3TL'	=> '', 
				'EL3Phone'	=> '', 
				'EL3Cell'	=> '', 
				'EL3Email1'	=> '', 
				'EL3Email2'	=> '', 
				'EL3Comments'	=> '',
				'Comments'	=> ''

	);	

	public function programs() {
			return $this->hasMany('Program');
	}

	public function assets() {
			return $this->hasMany('Asset');
	}
	public static function boot() {
		parent::boot();
		static::creating(function($team)
		{
			$team->created_by = Auth::id();
		});
		static::updating(function($team)
		{
			$team->updated_by = Auth::id();
		});
	}

}