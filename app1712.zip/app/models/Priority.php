<?php

class Priority extends Eloquent {
	
	protected $fillable = array('priority');

	public static $rules = array('priority'=>'required|min:2');
	
	public function programs() {
		return $this->hasMany('Program');
	}

}