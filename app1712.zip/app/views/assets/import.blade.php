@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">
@if(Auth::check())
<div class="row">
@include('includes.assetsmenu')
</div>
@endif


<!-- will be used to show any messages -->
@if (Session::has('message'))
	<div class="alert alert-info">{{ Session::get('message') }}</div>
@endif

{{ Form::open(array('url'=>'admin/assets/import','files'=>true)) }}
      {{ Form::label('file', 'Upload') }}
      {{ Form::file('file') }}

{{ Form::submit('Save') }}

  {{ Form::reset('Reset') }}
  
  {{ Form::close() }}

</div>

@stop