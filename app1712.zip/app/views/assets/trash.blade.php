@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">
@if(Auth::check())
<div class="row">
@include('includes.assetsmenu')
</div>
@endif


<!-- will be used to show any messages -->
@if (Session::has('message'))
	<div class="alert alert-info">{{ Session::get('message') }}</div>
@endif
<table class="table table-striped table-bordered">
  <thead>
    <tr>
      <td>ID</td>
      <td>Name</td>
      <td>Country</td>
      <td>Priority</td>
      <td>Deteled at</td>
      <td></td>
    </tr>
  </thead>
  <tbody>
@foreach($assets as $key => $value)
    <tr>
      <td>{{$value->id}}</id>
      <td><a href="{{ URL::to('admin/assets/' . $value->id) }}">{{ $value->name }}</a></td>
      <td>{{$value->country->name}}</id>
      <td>{{$value->priority->priority}}</id>
      <td>{{$value->deleted_at}}</id>
      <td>
          
        {{ Form::model($value, array('action' => array('AssetsController@restore', $value->id), 'class' => 'form-inline')) }}
        {{ Form::button('<i class="fa fa-plus-square fa-lg"></i> Restore', array('type' => 'submit', 'class' => 'btn btn-primary')) }}
        {{ Form::close() }}

      </td>
    </tr>
@endforeach
  </tbody>
</table>

</div>

@stop