<h1>Showing {{ $name }}</h1>


	<div class="jumbotron text-center">
		<h2>{{ $name }}</h2>
		<p>
			<strong>Email:</strong> {{ $priority }}<br>
			<strong>Level:</strong> {{ $country }}
		</p>

		View all details:

	<a class="btn btn-small btn-success" href="{{ URL::to('assets/show/' . $id) }}">Show details</a>
	</div>
</body>
</html>