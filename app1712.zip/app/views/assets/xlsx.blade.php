<table>
 <tbody>
  <tr>
   <td>Created At</td>
   <td>Name</td>
   <td>Email</td>
  </tr>
  @foreach($assets as $asset)
  <tr>
   <td>{{$asset['created_at']}}</td>
   <td>{{$asset['name']}}</td>
   <td>{{$asset['description']}}</td>
  </tr>
  @endforeach
 </tbody>
</table>