@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">
@if(Auth::check())
@include('includes.adminmenu')
@endif


<!-- will be used to show any messages -->
@if (Session::has('message'))
	<div class="alert alert-info">{{ Session::get('message') }}</div>
@endif

@foreach($teams as $key => $value)
<div class="row">
        <div class="col-md-12 criticality criticality3">
           <div class="row">
           	<div class="col-md-6">
            @if(Auth::check())  
            <h3><a href="{{ URL::to('admin/teams/' . $value->id) }}">{{ $value->team }}</a></h3>
            @else
            <h3><a href="{{ URL::to('teams/' . $value->id) }}">{{ $value->team }}</a></h3>
            @endif
            <p>{{ $value->TeamDescription }}</p>
        </div>
            <div class="col-md-6">
              @if(Auth::check())
            	<a class="btn btn-small btn-success" href="{{ URL::to('admin/teams/' . $value->id) }}"><i class="fa fa-info-circle fa-lg"></i> Show more</a>
          		@else
              <a class="btn btn-small btn-success" href="{{ URL::to('teams/' . $value->id) }}"><i class="fa fa-info-circle fa-lg"></i> Show more</a>
              @endif
              @if(Auth::check()) 
				      <a class="btn btn-small btn-danger" href="{{ URL::to('admin/teams/' . $value->id . '/edit') }}"><i class="fa fa-edit fa-lg"></i> Edit</a>

				      {{ Form::open(array('url' => 'admin/teams/' . $value->id, 'class' => 'form-inline')) }}
              {{ Form::hidden('_method', 'DELETE') }}
              {{ Form::button('<i class="fa fa-trash fa-lg"></i> Delete', array('type' => 'submit', 'class' => 'btn btn-warning')) }}
              {{ Form::close() }}
              @endif
			</div>
			</div>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
                <li><strong>Time table:</strong>{{ $value->TeamTimeTable }}</li>
                <li><strong>Phone:</strong>{{ $value->TeamPhone }}</li>
                <li><strong>Email:</strong>{{ $value->TeamEmail }}</li>
                <li><strong>Team Leader:</strong>{{ $value->EL1TL }}</li>
                <li><strong>Mobile:</strong>{{ $value->EL1Cell }}</li>
                <li><strong>Email:</strong>{{ $value->EL1Email1 }}</li>

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">
                <li><strong>Escalation L2:</strong>{{ $value->EL2TL }}</li>
                <li><strong>Mobile:</strong>{{ $value->EL2Cell }}</li>
                <li><strong>Email:</strong>{{ $value->EL2Email1 }}</li>
                                
                <li><strong>Escalation L3:</strong>{{ $value->EL3TL }}</li>
                <li><strong>Mobile:</strong>{{ $value->EL3Cell }}</li>
                <li><strong>Email:</strong>{{ $value->EL3Email1 }}</li>
           </ul>        
        </div>
      </div>
      </div>
</div>
@endforeach
<section id="pagination">
  {{ $teams->links() }}
</section>

</div>
</body>
</html>
@stop