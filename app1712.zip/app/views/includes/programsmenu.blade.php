<nav class="navbar navbar-inverse">
	<div class="navbar-header">
		<a class="navbar-brand" href="{{ URL::to('admin/programs') }}">Applications</a>
	</div>
	<ul class="nav navbar-nav">
		<li><a href="{{ URL::to('admin/programs') }}">View All Applications</a></li>
		<li><a href="{{ URL::to('admin/programs/create') }}">Create Applications</a>
		<li><a href="{{ URL::to('admin/programs/table') }}">Show as Table</a>
		<li><a href="{{ URL::to('admin/programs/import') }}">Import</a>
		<li><a href="{{ URL::to('admin/programs/export') }}">Export</a>
	</ul>

  
</nav>