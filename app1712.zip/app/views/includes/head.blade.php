<!doctype html>
<!--[if lt IE 7 ]> <html lang="en" class="ie ie6"> <![endif]-->
<!--[if IE 7 ]> <html lang="en" class="ie ie7"> <![endif]-->
<!--[if IE 8 ]> <html lang="en" class="ie ie8"> <![endif]-->
<!--[if IE 9 ]> <html lang="en" class="ie ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en"> <!--<![endif]-->

<head>
        <!-- META -->
        <meta charset="utf-8">

        <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1"><!-- Force IE to use the latest rendering engine -->
        <meta name="viewport" content="width=device-width, initial-scale=1"><!-- Optimize mobile viewport -->
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-capable" content="yes">

        <title>Matrix - home page</title>

        <!-- SCROLLS -->
       
        {{ HTML::style('css/bootstrap.min.css')}}
        {{ HTML::style('css/font-awesome.min.css')}}
        {{ HTML::style('css/animate.min.css')}}

        {{ HTML::style('css/style.css')}}
        {{ HTML::style('css/main.css')}}
        {{ HTML::style('css/demo-one.css')}}

       <script src="http://code.jquery.com/jquery-1.11.1.js"></script>
        {{ HTML::script('js/bootstrap.min.js')}}

        {{ HTML::style('css/bootstrap-combobox.css')}}
        {{ HTML::script('js/bootstrap-combobox.js')}}


</head>