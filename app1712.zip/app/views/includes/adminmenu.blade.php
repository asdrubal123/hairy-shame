<nav class="navbar navbar-inverse">
	<div class="navbar-header">
		<a class="navbar-brand" href="{{ URL::to('admin/teams') }}">Team Directory</a>
	</div>
	<ul class="nav navbar-nav">
		<li><a href="{{ URL::to('admin/teams') }}">View All Teams</a></li>
		<li><a href="{{ URL::to('admin/teams/create') }}">Create a Team</a>
		<li><a href="{{ URL::to('admin/teams/table') }}">Show as Table</a>
		<li><a href="{{ URL::to('admin/teams/import') }}">Import</a>
		<li><a href="{{ URL::to('admin/teams/export') }}">Export</a>
	</ul>

  
</nav>