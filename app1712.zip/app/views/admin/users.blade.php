@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">
@include('includes.adminmenu')

<div class="row">
  <div class="col-md-12">
  <h3>Users</h3>
  {{ $table->render() }}
  {{ $table->script() }}
  </div>
</div>
@stop
