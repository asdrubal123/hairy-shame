@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">

@include('includes.programsmenu')

<h1>Edit {{ $program->name }}</h1>
<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}
<div class="row">

{{ Form::model($program, array('action' => array('ProgramController@postCopy', $program->id))) }}
<div class="col-md-3">
			<div class='form-group'>
				<!-- `Name` Field -->
				{{ Form::label('name', 'Name') }}
				{{ Form::text('name', null, array('class' => 'form-control')) }}
			</div>
			<div class='form-group'>
				<!-- `Description` Field -->
				{{ Form::label('description', 'Description') }}
				{{ Form::text('description', null, array('class' => 'form-control')) }}
			</div>
			<div class='form-group'>
				<!-- `Country id` Field -->
				{{ Form::label('country_id', 'Country id') }}
				{{ Form::select('country_id', $countries) }}
			</div>
			<div class='form-group'>
				<!-- `Priority id` Field -->
				{{ Form::label('priority_id', 'Priority id') }}
				{{ Form::select('priority_id', $priorities) }}
			</div>
			<div class='form-group'>
				<!-- `Level1 team id` Field -->
				{{ Form::label('team_id', 'Level1 team id') }}
				{{ Form::select('team_id', $teams) }}
			</div>
			<div class='form-group'>
				<!-- `Level1 comment` Field -->
				{{ Form::label('level1_comment', 'Level1 comment') }}
				{{ Form::text('level1_comment', null, array('class' => 'form-control')) }}
			</div>
			<div class='form-group'>
				<!-- `Level2 team id` Field -->
				{{ Form::label('level2_team_id', 'Level2 team id') }}
				{{ Form::select('level2_team_id', $teams) }}
			</div>
			<div class='form-group'>
				<!-- `Level2 comment` Field -->
				{{ Form::label('level2_comment', 'Level2 comment') }}
				{{ Form::text('level2_comment', null, array('class' => 'form-control')) }}
			</div>
			<div class='form-group'>
				<!-- `Level3 team id` Field -->
				{{ Form::label('level3_team_id', 'Level3 team id') }}
				{{ Form::select('level3_team_id', $teams) }}			
			</div>
			<div class='form-group'>
				<!-- `Level3 comment` Field -->
				{{ Form::label('level3_comment', 'Level3 comment') }}
				{{ Form::text('level3_comment', null, array('class' => 'form-control')) }}
			</div>
			<div class='form-group'>
			{{ Form::label('active', 'Active') }}
				{{ Form::text('active', Input::old('active'), array('class' => 'form-control')) }}
			</div>

 

	{{ Form::submit('Edit Application', array('class' => 'btn btn-primary')) }}

{{ Form::close() }}

 
</div>
</div>
</body>
</html>
@stop
