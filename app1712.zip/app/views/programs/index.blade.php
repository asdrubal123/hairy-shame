@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">
@include('includes.programsmenu')



<!-- will be used to show any messages -->
@if (Session::has('message'))
	<div class="alert alert-info">{{ Session::get('message') }}</div>
@endif

@foreach($programs as $key => $value)
<div class="row">
        <div class="col-md-12 criticality criticality{{ $value->priority_id }}">
           <div class="row">
           	<div class="col-md-6">
            <h3><a href="{{ URL::to('admin/programs/' . $value->id) }}">{{ $value->name }}</a></h3>
            <p>{{ $value->description }}</p>
        </div>
            <div class="col-md-6">
            	<a class="btn btn-small btn-success" href="{{ URL::to('admin/programs/' . $value->id) }}"><i class="fa fa-info-circle fa-lg"></i> Show more</a>
          				<!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
				<a class="btn btn-small btn-danger" href="{{ URL::to('admin/programs/copy/' . $value->id) }}"><i class="fa fa-copy fa-lg"></i> Clone</a>
        <a class="btn btn-small btn-primary" href="{{ URL::to('admin/programs/' . $value->id . '/edit') }}"><i class="fa fa-edit fa-lg"></i> Edit</a>
				  {{ Form::open(array('url' => 'admin/programs/' . $value->id, 'class' => 'form-inline')) }}
          {{ Form::hidden('_method', 'DELETE') }}
          {{ Form::button('<i class="fa fa-trash fa-lg"></i> Delete', array('type' => 'submit', 'class' => 'btn btn-warning')) }}
          {{ Form::close() }}
			</div>
			</div>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
                <li><strong>Scope:</strong>{{ $value->country->name }}</li>
                <li><strong>Priority:</strong>{{ $value->priority->priority }}</li>
                <li><strong>1st line:</strong>{{ $value->team_id }}</li>
                <li><strong>1st line comment:</strong>{{ $value->level1_comment }}</li>
                <li><strong>2nd line:</strong>{{ $value->team_id }}</li>
                <li><strong>2nd line comment:</strong>{{ $value->level2_comment }}</li>

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">
                <li><strong>3rd line:</strong>{{ $value->team_id  }}</li>
                <li><strong>3rd line comment:</strong>{{ $value->level3_comment }}</li>
                <li><strong>Visible:</strong>{{ $value->active }}</li>
                                
  
           </ul>        
        </div>
      </div>
      </div>
</div>
@endforeach


</div>
</body>
</html>
@stop