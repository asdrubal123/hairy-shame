@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">
@include('includes.adminmenu')



<div class="row">
        <div class="col-md-12 criticality criticality3">
           <div class="row">
           	<div class="col-md-6">
            <h3>{{ $program->name }}</h3>
            <p>{{ $program->description }}</p>
        </div>
          <div class="col-md-6">
        <a href='{{URL::previous()}}' class='btn btn-small btn-primary'><i class="fa fa-arrow-circle-left fa-lg"></i> Back</a>
        <a class="btn btn-small btn-danger" href="{{ URL::to('admin/programs/' . $program->id . '/edit') }}"><i class="fa fa-edit fa-lg"></i> Edit</a>

          {{ Form::open(array('url' => 'admin/programs/' . $program->id, 'class' => 'form-inline')) }}
          {{ Form::hidden('_method', 'DELETE') }}
          {{ Form::button('<i class="fa fa-trash fa-lg"></i> Delete', array('type' => 'submit', 'class' => 'btn btn-warning')) }}
        {{ Form::close() }}
      </div>


			</div>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
              <li><strong>Scope:</strong>{{ $program->country->name }}</li>
                <li><strong>Priority:</strong>{{ $program->priority->priority }}</li>
                <li><strong>1st line:</strong>{{ $program->level1_team_id }}</li>
                <li><strong>1st line comment:</strong>{{ $program->level1_comment }}</li>
                <li><strong>2nd line:</strong>{{ $program->level2_team_id }}</li>
                <li><strong>2nd line comment:</strong>{{ $program->level2_comment }}</li>

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">
                <li><strong>3rd line:</strong>{{ $program->level3_team_id  }}</li>
                <li><strong>3rd line comment:</strong>{{ $program->level3_comment }}</li>
                <li><strong>Visible:</strong>{{ $program->active }}</li>


           </ul>        
        </div>
      </div>

            <div class="row">
          <div class="col-md-12">
            <p class="show-info">More comments here</p>
          </div>
      </div>
      </div>
</div>




</div>
</body>
</html>
@stop





