



<div class="row">
        <div class="col-md-12 criticality criticality3">
           <div class="row">
           	<div class="col-md-6">
            <h3>{{ $name }}</h3>
            <p>{{ $description }}</p>
        </div>



			</div>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">

     


           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">



           </ul>        
        </div>
      </div>

            <div class="row">
          <div class="col-md-12">
            <p class="show-info">More comments here</p>
          </div>
      </div>
      </div>
</div>




</div>






