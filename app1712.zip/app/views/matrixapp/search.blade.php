@extends('layouts.sidebar')



@section('content')
<div class="col-md-10">
@section('search-keyword')
  <section id="search-keyword">
    <h1>Search results for <strong>{{ $keyword }}</strong></h1>
  </section>  

@stop

@foreach($programs as $key => $value)
<div class="row">
        <div class="col-md-12 criticality criticality{{ $value->priority_id }}">
           <div class="row">
           	<div class="col-md-6">
            <h3><a href="matrixapp/view/{{ $value->id }}">{{ $value->name }}</a></h3>
            <p>{{ $value->description }}</p>
        </div>
            <div class="col-md-6">
            	<a class="btn btn-small btn-success" href="matrixapp/view/{{ $value->id }}"><i class="fa fa-info-circle fa-lg"></i> Show more</a>

			</div>
			</div>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
                <li><strong>Scope:</strong>{{ $value->country->name }}</li>
                <li><strong>Priority:</strong>{{ $value->priority->priority }}</li>
                <li><strong>1st line:</strong>{{ $value->level1_team_id }}</li>
                <li><strong>1st line comment:</strong>{{ $value->level1_comment }}</li>
                <li><strong>2nd line:</strong>{{ $value->level2_team_id }}</li>
                <li><strong>2nd line comment:</strong>{{ $value->level2_comment }}</li>

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">
                <li><strong>3rd line:</strong>{{ $value->level3_team_id  }}</li>
                <li><strong>3rd line comment:</strong>{{ $value->level3_comment }}</li>
                <li><strong>Visible:</strong>{{ $value->active }}</li>
                                
  
           </ul>        
        </div>
      </div>
      </div>
</div>
@endforeach




</div>



@stop