@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">

<nav class="navbar navbar-inverse">
	<div class="navbar-header">
		<a class="navbar-brand" href="{{ URL::to('teams') }}">Team Directory</a>
	</div>
	<ul class="nav navbar-nav">
		<li><a href="{{ URL::to('teams') }}">View All Teams</a></li>
		<li><a href="{{ URL::to('teams/create') }}">Create a Team</a>
		<li><a href="{{ URL::to('teams/table') }}">Show as Table</a>
		<li><a href="{{ URL::to('teams/import') }}">Import</a>
		<li><a href="{{ URL::to('teams/export') }}">Export</a>
	</ul>
</nav>



<div class="row">
        <div class="col-md-12 criticality criticality3">
           <div class="row">
           	<div class="col-md-6">
            <h3>{{ $team->Team }}</h3>
            <p>{{ $team->TeamDescription }}</p>
        </div>


			</div>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
                <li><strong>Status:</strong>{{ $team->TeamStatus }}</li>
                <li><strong>Service Level:</strong>{{ $team->TeamSL }}</li>
                <li><strong>Customer:</strong>{{ $team->TeamCust }}</li>
                <li><strong>Time table:</strong>{{ $team->TeamTimeTable }}</li>
                <li><strong>Phone:</strong>{{ $team->TeamPhone }}</li>
                <li><strong>Phone Const:</strong>{{ $team->TeamConstraintPhone }}</li>
                <li><strong>Email:</strong>{{ $team->TeamEmail }}</li>
                <li><strong></strong>{{ $team->TeamFree1 }}</li>
                <li><strong></strong>{{ $team->EFree }}</li>
                <li><strong>Team Leader:</strong>{{ $team->EL1TL }}</li>
                <li><strong>Phone:</strong>{{ $team->EL1Phone }}</li>
                <li><strong>Mobile:</strong>{{ $team->EL1Cell }}</li>
                <li><strong>Email:</strong>{{ $team->EL1Email1 }}</li>
                <li><strong>Email2:</strong>{{ $team->EL1Email2 }}</li>
                <li><strong>Additional info:</strong>{{ $team->EL1Comments }}</li>

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">
                <li><strong>Escalation L2:</strong>{{ $team->EL2TL }}</li>
                <li><strong>Phone:</strong>{{ $team->EL2Phone }}</li>
                <li><strong>Mobile:</strong>{{ $team->EL2Cell }}</li>
                <li><strong>Email:</strong>{{ $team->EL2Email1 }}</li>
                <li><strong>Email2:</strong>{{ $team->EL2Email2 }}</li>
                <li><strong>Additional info:</strong>{{ $team->EL2Comments }}</li>
                <li><strong>Escalation L3:</strong>{{ $team->EL3TL }}</li>
                <li><strong>Phone:</strong>{{ $team->EL3Phone }}</li>
                <li><strong>Mobile:</strong>{{ $team->EL3Cell }}</li>
                <li><strong>Email:</strong>{{ $team->EL3Email1 }}</li>
                <li><strong>Email2:</strong>{{ $team->EL3Email2 }}</li>
                <li><strong>Additional info:</strong>{{ $team->EL3Comments }}</li>

           </ul>        
        </div>
      </div>
      <div class="row">
          <div class="col-md-12">
            <p class="show-info">{{ $team->Comments }}</p>
          </div>
      </div>

      </div>
</div>




</div>
</body>
</html>
@stop  
       

