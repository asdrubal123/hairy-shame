@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">

<nav class="navbar navbar-inverse">
	<div class="navbar-header">
		<a class="navbar-brand" href="{{ URL::to('teams') }}">Team Directory</a>
	</div>
	<ul class="nav navbar-nav">
		<li><a href="{{ URL::to('teams') }}">View All Teams</a></li>
		<li><a href="{{ URL::to('teams/create') }}">Create a Team</a>
	</ul>
</nav>

<h1>Edit {{ $team->Team }}</h1>
<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}
<div class="row">


{{ Form::model($team, array('route' => array('teams.update', $team->id), 'method' => 'PUT')) }}<div class="col-md-3">
	<div class="form-group">
		{{ Form::label('Team', 'Team') }}
		{{ Form::text('Team', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamStatus', 'Status') }}
		{{ Form::text('TeamStatus', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamDescription', 'Description') }}
		{{ Form::text('TeamDescription', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamSL', 'TeamSL') }}
		{{ Form::text('TeamSL', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamCust', 'TeamCust') }}
		{{ Form::text('TeamCust', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamTimeTable', 'Working Hours') }}
		{{ Form::text('TeamTimeTable', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamPhone', 'Phone') }}
		{{ Form::text('TeamPhone', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamConstraintPhone', 'ConstraintPhone') }}
		{{ Form::text('TeamConstraintPhone', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamEmail', 'Email') }}
		{{ Form::text('TeamEmail', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamFree1', 'TeamFree1') }}
		{{ Form::text('TeamFree1', null, array('class' => 'form-control')) }}
	</div>
    </div>
	<div class="col-md-3">
		<div class="form-group">
		{{ Form::label('EFree', 'EFree') }}
		{{ Form::text('EFree', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1TL', 'EL1TL') }}
		{{ Form::text('EL1TL', null, array('class' => 'form-control')) }}
	</div>	<div class="form-group">
		{{ Form::label('EL1Phone', 'EL1Phone') }}
		{{ Form::text('EL1Phone', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1Cell', 'EL1Cell') }}
		{{ Form::text('EL1Cell', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1Email1', 'EL1Email1') }}
		{{ Form::text('EL1Email1', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1Email2', 'EL1Email2') }}
		{{ Form::text('EL1Email2', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1Comments', 'EL1Comments') }}
		{{ Form::text('EL1Comments', null, array('class' => 'form-control')) }}
	</div>

   


			<div class="form-group">
		{{ Form::label('EL2TL', 'EL2TL') }}
		{{ Form::text('EL2TL', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL2Phone', 'EL2Phone') }}
		{{ Form::text('EL2Phone', null, array('class' => 'form-control')) }}
	</div>
	
		<div class="form-group">
		{{ Form::label('EL2Cell', 'EL2Cell') }}
		{{ Form::text('EL2Cell', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL2Email1', 'EL2Email1') }}
		{{ Form::text('EL2Email1', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL2Email2', 'EL2Email2') }}
		{{ Form::text('EL2Email2', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL2Comments', 'EL2Comments') }}
		{{ Form::text('EL2Comments', null, array('class' => 'form-control')) }}
	</div>

    </div>
	<div class="col-md-3">

		<div class="form-group">
		{{ Form::label('EL3TL', 'EL3TL') }}
		{{ Form::text('EL3TL', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL3Phone', 'EL3Phone') }}
		{{ Form::text('EL3Phone', null, array('class' => 'form-control')) }}
	</div>
	
		<div class="form-group">
		{{ Form::label('EL3Cell', 'EL3Cell') }}
		{{ Form::text('EL3Cell', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL3Email1', 'EL3Email1') }}
		{{ Form::text('EL3Email1', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL3Email2', 'EL3Email2') }}
		{{ Form::text('EL3Email2', null, array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL3Comments', 'EL3Comments') }}
		{{ Form::text('EL3Comments', null, array('class' => 'form-control')) }}
	</div>
   </div>
	<div class="col-md-3">

	
		<div class="form-group">
		{{ Form::label('Comments', 'Comments') }}
		{{ Form::textarea('Comments', null, array('class' => 'form-control')) }}
	</div>

	{{ Form::submit('Edit Team', array('class' => 'btn btn-primary')) }}

{{ Form::close() }}
</div>
</div>
</div>
</body>
</html>
@stop