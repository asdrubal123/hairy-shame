@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">

<nav class="navbar navbar-inverse">
	<div class="navbar-header">
		<a class="navbar-brand" href="{{ URL::to('teams') }}">Team Directory</a>
	</div>
	<ul class="nav navbar-nav">
		<li><a href="{{ URL::to('admin/teams') }}">View All Teams</a></li>
		<li><a href="{{ URL::to('admin/teams/create') }}">Create a Team</a>
	</ul>
</nav>


<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}
<div class="row">

{{ Form::open(array('url' => 'admin/teams')) }}
<div class="col-md-3">
	<div class="form-group">
		{{ Form::label('Team', 'Team') }}
		{{ Form::text('Team', Input::old('Team'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamStatus', 'Status') }}
		{{ Form::text('TeamStatus', Input::old('TeamStatus'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamDescription', 'Description') }}
		{{ Form::text('TeamDescription', Input::old('TeamDescription'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamSL', 'TeamSL') }}
		{{ Form::text('TeamSL', Input::old('TeamSL'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamCust', 'TeamCust') }}
		{{ Form::text('TeamCust', Input::old('TeamCust'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamTimeTable', 'Working Hours') }}
		{{ Form::text('TeamTimeTable', Input::old('TeamTimeTable'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamPhone', 'Phone') }}
		{{ Form::text('TeamPhone', Input::old('TeamPhone'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamConstraintPhone', 'ConstraintPhone') }}
		{{ Form::text('TeamConstraintPhone', Input::old('TeamConstraintPhone'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamEmail', 'Email') }}
		{{ Form::text('TeamEmail', Input::old('TeamEmail'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('TeamFree1', 'TeamFree1') }}
		{{ Form::text('TeamFree1', Input::old('TeamFree1'), array('class' => 'form-control')) }}
	</div>
    </div>
	<div class="col-md-3">
		<div class="form-group">
		{{ Form::label('EFree', 'EFree') }}
		{{ Form::text('EFree', Input::old('EFree'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1TL', 'EL1TL') }}
		{{ Form::text('EL1TL', Input::old('EL1TL'), array('class' => 'form-control')) }}
	</div>	<div class="form-group">
		{{ Form::label('EL1Phone', 'EL1Phone') }}
		{{ Form::text('EL1Phone', Input::old('EL1Phone'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1Cell', 'EL1Cell') }}
		{{ Form::text('EL1Cell', Input::old('EL1Cell'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1Email1', 'EL1Email1') }}
		{{ Form::text('EL1Email1', Input::old('EL1Email1'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1Email2', 'EL1Email2') }}
		{{ Form::text('EL1Email2', Input::old('EL1Email2'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL1Comments', 'EL1Comments') }}
		{{ Form::text('EL1Comments', Input::old('EL1Comments'), array('class' => 'form-control')) }}
	</div>

   


			<div class="form-group">
		{{ Form::label('EL2TL', 'EL2TL') }}
		{{ Form::text('EL2TL', Input::old('EL2TL'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL2Phone', 'EL2Phone') }}
		{{ Form::text('EL2Phone', Input::old('EL2Phone'), array('class' => 'form-control')) }}
	</div>
	
		<div class="form-group">
		{{ Form::label('EL2Cell', 'EL2Cell') }}
		{{ Form::text('EL2Cell', Input::old('EL2Cell'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL2Email1', 'EL2Email1') }}
		{{ Form::text('EL2Email1', Input::old('EL2Email1'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL2Email2', 'EL2Email2') }}
		{{ Form::text('EL2Email2', Input::old('EL2Email2'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL2Comments', 'EL2Comments') }}
		{{ Form::text('EL2Comments', Input::old('EL2Comments'), array('class' => 'form-control')) }}
	</div>

    </div>
	<div class="col-md-3">

		<div class="form-group">
		{{ Form::label('EL3TL', 'EL3TL') }}
		{{ Form::text('EL3TL', Input::old('EL3TL'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL3Phone', 'EL3Phone') }}
		{{ Form::text('EL3Phone', Input::old('EL3Phone'), array('class' => 'form-control')) }}
	</div>
	
		<div class="form-group">
		{{ Form::label('EL3Cell', 'EL3Cell') }}
		{{ Form::text('EL3Cell', Input::old('EL3Cell'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL3Email1', 'EL3Email1') }}
		{{ Form::text('EL3Email1', Input::old('EL3Email1'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL3Email2', 'EL3Email2') }}
		{{ Form::text('EL3Email2', Input::old('EL3Email2'), array('class' => 'form-control')) }}
	</div>
		<div class="form-group">
		{{ Form::label('EL3Comments', 'EL3Comments') }}
		{{ Form::text('EL3Comments', Input::old('EL3Comments'), array('class' => 'form-control')) }}
	</div>
   </div>
	<div class="col-md-3">

		<div class="form-group">
		{{ Form::label('Comments', 'Comments') }}
		{{ Form::textarea('Comments', Input::old('Comments'), array('class' => 'form-control')) }}
	</div>

	{{ Form::submit('Create new Team', array('class' => 'btn btn-primary')) }}

{{ Form::close() }}
</div>
</div>
</div>
</body>
</html>
@stop