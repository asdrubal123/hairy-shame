@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">

<nav class="navbar navbar-inverse">
	<div class="navbar-header">
		<a class="navbar-brand" href="{{ URL::to('teams') }}">Team Directory</a>
	</div>
	<ul class="nav navbar-nav">
		<li><a href="{{ URL::to('teams') }}">View All Teams</a></li>
		<li><a href="{{ URL::to('admin/teams/create') }}">Create a Team</a>
		<li><a href="{{ URL::to('teams/table') }}">Show as Table</a>
		<li><a href="{{ URL::to('teams/import') }}">Import</a>
		<li><a href="{{ URL::to('teams/export') }}">Export</a>
	</ul>

  
</nav>



<!-- will be used to show any messages -->
@if (Session::has('message'))
	<div class="alert alert-info">{{ Session::get('message') }}</div>
@endif

@foreach($teams as $key => $value)
<div class="row">
        <div class="col-md-12 criticality criticality3">
           <div class="row">
           	<div class="col-md-6">
            <h3><a href="show/{{ $value->id }}">{{ $value->Team }}</a></h3>
            <h3><a href="{{ URL::to('admin/teams/show/' . $value->id) }}">{{ $value->Team }}</a></h3>
            <p>{{ $value->TeamDescription }}</p>
        </div>
            <div class="col-md-2">
            	<a class="btn btn-small btn-success" href="{{ URL::to('admin/teams/show/' . $value->id) }}">Show this Team</a>
              <a class="btn btn-small btn-success" href="show/{{ $value->id }}">Show this Team</a>
            </div>
            <div class="col-md-2">
				<!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
				<a class="btn btn-small btn-danger" href="{{ URL::to('admin/teams/edit/' . $value->id) }}">Edit this Team</a>
			</div>
			    <div class="col-md-2">
          {{ Form::open(array('url'=>'admin/teams/' . $value->id . '/edit', 'class'=>'form-inline')) }}
          {{ Form::hidden('id', $value->id) }}
          {{ Form::button('<i class="fa fa-edit fa-lg"></i> Edit', array('type' => 'submit', 'class' => 'btn btn-primary')) }}
          {{ Form::close() }}

          {{ Form::open(array('url'=>'admin/teams/destroy', 'class'=>'form-inline')) }}
          {{ Form::hidden('id', $value->id) }}
          {{ Form::button('<i class="fa fa-trash fa-lg"></i> Delete', array('type' => 'submit', 'class' => 'btn btn-warning')) }}
          {{ Form::close() }}
			</div>
			</div>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
                <li><strong>Time table:</strong>{{ $value->TeamTimeTable }}</li>
                <li><strong>Phone:</strong>{{ $value->TeamPhone }}</li>
                <li><strong>Email:</strong>{{ $value->TeamEmail }}</li>
                <li><strong>Team Leader:</strong>{{ $value->EL1TL }}</li>
                <li><strong>Mobile:</strong>{{ $value->EL1Cell }}</li>
                <li><strong>Email:</strong>{{ $value->EL1Email1 }}</li>
                            

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">

                <li><strong>Escalation L2:</strong>{{ $value->EL2TL }}</li>
                <li><strong>Mobile:</strong>{{ $value->EL2Cell }}</li>
                <li><strong>Email:</strong>{{ $value->EL2Email1 }}</li>
                                
                <li><strong>Escalation L3:</strong>{{ $value->EL3TL }}</li>
                <li><strong>Mobile:</strong>{{ $value->EL3Cell }}</li>
                <li><strong>Email:</strong>{{ $value->EL3Email1 }}</li>
           </ul>        
        </div>
      </div>
      </div>
</div>
@endforeach


</div>
</body>
</html>
@stop