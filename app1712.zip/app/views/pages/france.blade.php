@extends('layouts.sidebar')

@section('content')
<div class="col-md-10">
<div class="row">
        <div class="col-md-12 criticality criticality1">
           
            <h3>Lotus Notes</h3>
            <p>some description</p>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
                <li><strong>Criticality:</strong> gjk</li>
                <li><strong>Site:</strong> kjlhg</li>
                <li><strong>Provider:</strong> jhkg</li>
                <li><strong>Responsible:</strong> kjhg</li>
                <li><strong>Additonal Info:</strong> kjfhg</li>

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">
                <li><strong>Build type:</strong> gjk</li>
                <li><strong>Primary Farm:</strong> kjlhg</li>
                <li><strong>Backup Farm:</strong> jhkg</li>
                <li><strong>Place:</strong> kjhg</li>
                <li><strong>When added:</strong> kjfhg</li>

           </ul>        
        </div>
      </div>
      </div>
</div>

<div class="row">
        <div class="col-md-12 criticality criticality2">
           
            <h3>Lotus Notes</h3>
            <p>some description</p>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
                <li><strong>Criticality:</strong> gjk</li>
                <li><strong>Site:</strong> kjlhg</li>
                <li><strong>Provider:</strong> jhkg</li>
                <li><strong>Responsible:</strong> kjhg</li>
                <li><strong>Additonal Info:</strong> kjfhg</li>

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">
                <li><strong>Build type:</strong> gjk</li>
                <li><strong>Primary Farm:</strong> kjlhg</li>
                <li><strong>Backup Farm:</strong> jhkg</li>
                <li><strong>Place:</strong> kjhg</li>
                <li><strong>When added:</strong> kjfhg</li>

           </ul>        
        </div>
      </div>
      </div>
</div>

<div class="row">
        <div class="col-md-12 criticality criticality3">
           
            <h3>Lotus Notes</h3>
            <p>some description</p>
    <div class="row">
        <div class="col-md-6">    
            <ul class="show-info">
                <li><strong>Criticality:</strong> gjk</li>
                <li><strong>Site:</strong> kjlhg</li>
                <li><strong>Provider:</strong> jhkg</li>
                <li><strong>Responsible:</strong> kjhg</li>
                <li><strong>Additonal Info:</strong> kjfhg</li>

           </ul> 


        </div>
        <div class="col-md-6">
          <ul class="show-info">
                <li><strong>Build type:</strong> gjk</li>
                <li><strong>Primary Farm:</strong> kjlhg</li>
                <li><strong>Backup Farm:</strong> jhkg</li>
                <li><strong>Place:</strong> kjhg</li>
                <li><strong>When added:</strong> kjfhg</li>

           </ul>        
        </div>
      </div>
      </div>
</div>
</div>
@stop