<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
	return View::make('pages.home');
});
Route::get('france', function()
{	
	return View::make('pages.france');
});
Route::get('belgium', function()
{	
	return View::make('pages.belgium');
});


/*Route::get('nerds/table', array('uses' => 'NerdController@table'));

Route::resource('nerds', 'NerdController');*/


/*
Route::post(
    'nerds/search',
	    array(
	        'as' => 'nerds.search',
	        'uses' => 'NerdController@postSearch'
	    )
	);
*/



/*Route::post('admin/teams/{id}/edit', 'TeamController@update');*/
/*Route::get('admin/teams/{id}', 'TeamController@showTeam');*/
/*Route::get('admin/teams/table', array('uses' => 'TeamController@table'));*/
/*Route::controller('admin/teams', 'TeamController');*/


Route::get('admin/teams/table', 'TeamController@table');
Route::resource('admin/teams', 'TeamController');
Route::get('teams', 'TeamController@userindex');
Route::get('teams/{id}', 'TeamController@usershow');

Route::controller('admin/countries', 'CountryController');
Route::controller('admin/priorities', 'PriorityController');
Route::controller('admin/users', 'UserController');
Route::get('users/signin', 'UserController@getSignin');
Route::get('admin/programs/active', 'ProgramController@getActive');
Route::get('admin/country/{id}', 'ProgramController@getCountry');
Route::resource('admin/programs', 'ProgramController');
Route::get('admin/programs/copy/{id}', 'ProgramController@getCopy');
Route::post('admin/programs/copy/{id}', 'ProgramController@postCopy');

Route::get('admin/assets/trash', 'AssetsController@getSoftDeleted');
Route::post('admin/assets/restore/{id}', 'AssetsController@restore');
Route::get('admin/assets/import', 'AssetsController@getUpload');
Route::post('admin/assets/import', 'AssetsController@postUpload');
Route::resource('admin/assets', 'AssetsController');
Route::get('admin/assets/country/{id}', 'AssetsController@getCountry');
Route::get('admin/assets/copy/{id}', 'AssetsController@getCopy');
Route::post('admin/assets/copy/{id}', 'AssetsController@postCopy');
Route::post('admin/assets/send/{id}', 'AssetsController@postSend');
Route::get('exportassets', array('as'=>'admin.assets.exportassets', 'uses'=>'ExportController@exportassets'));

Route::get('assets', 'AssetsController@userindex');
Route::get('assets/{id}', 'AssetsController@usershow');
Route::get('assets/country/{id}', 'AssetsController@getCountryUser');


Route::controller('matrixapp', 'MatrixappController');

Route::controller('password', 'RemindersController');

Route::controller('nerds', 'NerdController');


Route::get('api/nerds', array('as'=>'api.nerds', 'uses'=>'NerdController@getDatatable'));
Route::get('/export-to-csv', function() {
    $nerds = Nerd::all();

    // the csv file with the first row
    $output = implode(",", array('id', 'name', 'email', 'nerd_level', 'created_at', 'updated_at'));
    $output .= "\n";
    
    foreach ($nerds as $row) {

        $output .=  implode(",", array($row['id'], $row['name'], $row['email'], $row['nerd_level'], $row['created_at'], $row['updated_at'])); // append each row
   		$output .= "\n";
    }

    // headers used to make the file "downloadable", we set them manually
    // since we can't use Laravel's Response::download() function
    $headers = array(
        'Content-Type' => 'text/csv',
        'Content-Disposition' => 'attachment; filename="nerds.csv"',
        );

    // our response, this will be equivalent to your download() but
    // without using a local file
    return Response::make(rtrim($output, "\n"), 200, $headers);
});