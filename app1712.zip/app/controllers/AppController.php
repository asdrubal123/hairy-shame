<?php

class AppController extends BaseController {
     
	public function __construct() {
		$this->beforeFilter('csrf', array('on'=>'post'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
				// get all the teams
		$apps = App::all();

		// load the view and pass the nerds
		return View::make('apps.index')
			->with('app', $app);
	}
    public function table()
	{		// get all the nerds
		$apps = App::all();

		// load the view and pass the nerds
        
		return View::make('apps.table')
			->with('app', $app);
	
	}
	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('apps.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{


		$validator = Validator::make(Input::all(), App::$rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('admin/apps/create')
				->withErrors($validator)
				->withInput();
		} else {
			// store
			$app = new App;
			$app->name = Input::get('name');
			$app->description = Input::get('description');
			$app->country_id = Input::get('country_id');
			$app->priority_id = Input::get('priority_id');
			$app->level1_team_id = Input::get('level1_team_id');
			$app->level1_comment = Input::get('level1_comment');
			$app->level2_team_id = Input::get('level2_team_id');
			$app->level2_comment = Input::get('level2_comment');
			$app->level3_team_id = Input::get('level3_team_id');
			$app->level3_comment = Input::get('level3_comment');
			$app->active = Input::get('active');
			$app->save();


		
			// redirect
			Session::flash('message', 'Successfully created Application!');
			return Redirect::to('admin/apps');
		}
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
						// get the team
		$app = App::find($id);

		// show the view and pass the team to it
		return View::make('apps.show')
			->with('app', $app);
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
				// get the team
		$app = App::find($id);

		// show the edit form and pass the team
		return View::make('apps.edit')
			->with('app', $app);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
						// validate
		// read more on validation at http://laravel.com/docs/validation

		$validator = Validator::make(Input::all(), App::$rules);

		// process the login
		if ($validator->fails()) {
			return Redirect::to('admin/apps/' . $id . '/edit')
				->withErrors($validator)
				->withInput();
		} else {
			// store
			$app = new App;
			$app->name = Input::get('name');
			$app->description = Input::get('description');
			$app->country_id = Input::get('country_id');
			$app->priority_id = Input::get('priority_id');
			$app->level1_team_id = Input::get('level1_team_id');
			$app->level1_comment = Input::get('level1_comment');
			$app->level2_team_id = Input::get('level2_team_id');
			$app->level2_comment = Input::get('level2_comment');
			$app->level3_team_id = Input::get('level3_team_id');
			$app->level3_comment = Input::get('level3_comment');
			$app->active = Input::get('active');
			$app->save();


			// redirect
			Session::flash('message', 'Successfully updated application!');
			return Redirect::to('admin/apps');
		}
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
				// delete
		$app = App::find($id);
		$app->delete();

		// redirect
		Session::flash('message', 'Successfully deleted application!');
		return Redirect::to('admin/apps');
	}

}