<?php

class MatrixappController extends BaseController {

	public function __construct() {
		parent::__construct();
		$this->beforeFilter('csrf', array('on'=>'post'));
	}

	public function getIndex() {
		return View::make('matrixapp.index')
			->with('programs', Program::orderBy('created_at', 'DESC')->paginate(5));
	}
	public function getView($id) {
		return View::make('matrixapp.view')->with('program', Program::find($id));
	}

	public function getCountry($cou_id) {
		return View::make('matrixapp.country')
			->with('programs', Program::where('country_id', '=', $cou_id)->paginate(5))
			->with('country', Country::find($cou_id));
	}

	public function getSearch() {
		$keyword = Input::get('keyword');

		return View::make('matrixapp.search')
			->with('programs', Program::where('name', 'LIKE', '%'.$keyword.'%')->get())
			->with('keyword', $keyword);
	}
}